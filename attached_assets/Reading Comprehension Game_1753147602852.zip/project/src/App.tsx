import React, { useState, useEffect } from 'react';
import { ChevronRight, RotateCcw, BookOpen, Star, CheckCircle, XCircle } from 'lucide-react';

interface Question {
  question: string;
  options: string[];
  correctAnswer: number;
  explanation?: string;
}

interface Story {
  title: string;
  content: string;
  questions: Question[];
}

const stories: Story[] = [
  {
    title: "The Helpful Squirrel",
    content: "Sammy the squirrel lived in a big oak tree. Every morning, he would collect acorns for winter. One day, he saw a little bird who had hurt its wing and couldn't fly. Sammy shared his acorns with the bird and helped build a cozy nest on a low branch. The bird was so grateful for Sammy's kindness. When winter came, the bird sang beautiful songs to keep Sammy company during the cold days.",
    questions: [
      {
        question: "What did Sammy do every morning?",
        options: ["Sleep in his nest", "Collect acorns", "Sing songs", "Fly around"],
        correctAnswer: 1,
        explanation: "The story says Sammy collected acorns every morning to prepare for winter."
      },
      {
        question: "Why couldn't the little bird fly?",
        options: ["It was too young", "It hurt its wing", "It was scared", "It was sleeping"],
        correctAnswer: 1,
        explanation: "The story tells us the bird had hurt its wing and couldn't fly."
      },
      {
        question: "How did the bird thank Sammy?",
        options: ["By giving him acorns", "By flying away", "By singing songs", "By building a nest"],
        correctAnswer: 2,
        explanation: "When winter came, the bird sang beautiful songs to keep Sammy company."
      }
    ]
  },
  {
    title: "The Magic Garden",
    content: "Emma discovered a secret garden behind her grandmother's house. The garden was full of flowers that changed colors throughout the day. In the morning, they were bright yellow like the sun. By afternoon, they turned pink and purple. At night, they glowed soft blue like moonlight. Emma's grandmother explained that the flowers were magic and only bloomed for people with kind hearts. Emma visited the garden every day and took care of the special flowers.",
    questions: [
      {
        question: "Where did Emma find the secret garden?",
        options: ["At school", "Behind her grandmother's house", "In the park", "At her friend's house"],
        correctAnswer: 1,
        explanation: "Emma found the secret garden behind her grandmother's house."
      },
      {
        question: "What color were the flowers in the morning?",
        options: ["Pink and purple", "Soft blue", "Bright yellow", "Green"],
        correctAnswer: 2,
        explanation: "The story says the flowers were bright yellow like the sun in the morning."
      },
      {
        question: "According to grandmother, who can see the magic flowers bloom?",
        options: ["Anyone who finds them", "People with kind hearts", "Only children", "Only grown-ups"],
        correctAnswer: 1,
        explanation: "Grandmother explained the flowers only bloomed for people with kind hearts."
      }
    ]
  },
  {
    title: "The Brave Little Turtle",
    content: "Terry the turtle was the smallest in his family, but he had the biggest dreams. All the other turtles were afraid to cross the busy stream to reach the sweet berries on the other side. Terry was scared too, but he wanted to help his hungry family. He practiced swimming every day until he became strong and fast. Finally, Terry crossed the stream safely and brought back delicious berries for everyone. His family was so proud of his courage and determination.",
    questions: [
      {
        question: "What made Terry different from other turtles in his family?",
        options: ["He was the fastest", "He was the smallest", "He was the oldest", "He was the strongest"],
        correctAnswer: 1,
        explanation: "The story says Terry was the smallest turtle in his family."
      },
      {
        question: "Why were the other turtles afraid?",
        options: ["The berries were poisonous", "The stream was busy/dangerous", "It was too dark", "They didn't like berries"],
        correctAnswer: 1,
        explanation: "The other turtles were afraid to cross the busy stream."
      },
      {
        question: "How did Terry prepare for crossing the stream?",
        options: ["He asked for help", "He practiced swimming every day", "He waited for winter", "He found a boat"],
        correctAnswer: 1,
        explanation: "Terry practiced swimming every day until he became strong and fast."
      }
    ]
  },
  {
    title: "The Friendly Robot",
    content: "In a small town, there lived a robot named Beep who loved to help people. Every morning, Beep would walk around the neighborhood looking for ways to be helpful. He would water plants for busy families, carry heavy groceries for elderly neighbors, and even help children find their lost toys. At first, some people were nervous around Beep because they had never seen a robot before. But soon, everyone loved Beep because he was so kind and helpful. The town became a happier place with Beep around.",
    questions: [
      {
        question: "What was the robot's name?",
        options: ["Buzz", "Beep", "Bob", "Ben"],
        correctAnswer: 1,
        explanation: "The robot's name was Beep."
      },
      {
        question: "Why were some people nervous around Beep at first?",
        options: ["He was too loud", "They had never seen a robot before", "He was too big", "He was mean"],
        correctAnswer: 1,
        explanation: "People were nervous because they had never seen a robot before."
      },
      {
        question: "What happened to the town because of Beep?",
        options: ["It became quieter", "It became sadder", "It became a happier place", "Nothing changed"],
        correctAnswer: 2,
        explanation: "The story says the town became a happier place with Beep around."
      }
    ]
  },
  {
    title: "The Musical Butterfly",
    content: "Luna was a butterfly with wings that made beautiful music when she flew. Every note was different - some high and sweet, others low and gentle. The other animals in the forest loved to listen to Luna's music. When baby animals couldn't sleep, Luna would fly around their nests playing soft lullabies. When the forest felt sad during rainy days, Luna would play cheerful songs to lift everyone's spirits. Luna learned that her special gift could bring joy and comfort to all her forest friends.",
    questions: [
      {
        question: "What was special about Luna's wings?",
        options: ["They were very colorful", "They made beautiful music", "They were very large", "They glowed in the dark"],
        correctAnswer: 1,
        explanation: "Luna's wings made beautiful music when she flew."
      },
      {
        question: "What did Luna play for baby animals?",
        options: ["Loud music", "Soft lullabies", "Dance music", "No music"],
        correctAnswer: 1,
        explanation: "Luna would play soft lullabies to help baby animals sleep."
      },
      {
        question: "What did Luna learn about her gift?",
        options: ["It was annoying", "It was useless", "It could bring joy and comfort", "It scared other animals"],
        correctAnswer: 2,
        explanation: "Luna learned that her special gift could bring joy and comfort to all her forest friends."
      }
    ]
  }
];

function App() {
  const [currentStory, setCurrentStory] = useState<Story | null>(null);
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
  const [selectedAnswer, setSelectedAnswer] = useState<number | null>(null);
  const [showFeedback, setShowFeedback] = useState(false);
  const [score, setScore] = useState(0);
  const [gamePhase, setGamePhase] = useState<'start' | 'story' | 'questions' | 'complete'>('start');
  const [answeredQuestions, setAnsweredQuestions] = useState<boolean[]>([]);

  const startGame = () => {
    const randomStory = stories[Math.floor(Math.random() * stories.length)];
    setCurrentStory(randomStory);
    setCurrentQuestionIndex(0);
    setSelectedAnswer(null);
    setShowFeedback(false);
    setScore(0);
    setGamePhase('story');
    setAnsweredQuestions(new Array(randomStory.questions.length).fill(false));
  };

  const startQuestions = () => {
    setGamePhase('questions');
  };

  const handleAnswerSelect = (answerIndex: number) => {
    if (showFeedback) return;
    setSelectedAnswer(answerIndex);
  };

  const handleKeyPress = (event: React.KeyboardEvent, answerIndex: number) => {
    if (event.key === 'Enter' || event.key === ' ') {
      event.preventDefault();
      handleAnswerSelect(answerIndex);
    }
  };

  const submitAnswer = () => {
    if (selectedAnswer === null || !currentStory) return;

    const isCorrect = selectedAnswer === currentStory.questions[currentQuestionIndex].correctAnswer;
    if (isCorrect) {
      setScore(score + 1);
    }

    const newAnsweredQuestions = [...answeredQuestions];
    newAnsweredQuestions[currentQuestionIndex] = true;
    setAnsweredQuestions(newAnsweredQuestions);

    setShowFeedback(true);
  };

  const nextQuestion = () => {
    if (!currentStory) return;

    if (currentQuestionIndex < currentStory.questions.length - 1) {
      setCurrentQuestionIndex(currentQuestionIndex + 1);
      setSelectedAnswer(null);
      setShowFeedback(false);
    } else {
      setGamePhase('complete');
    }
  };

  const resetGame = () => {
    setGamePhase('start');
    setCurrentStory(null);
  };

  const getEncouragementMessage = () => {
    if (!currentStory) return '';
    const percentage = (score / currentStory.questions.length) * 100;
    if (percentage === 100) return "Perfect! You're an amazing reader! 🌟";
    if (percentage >= 80) return "Excellent work! You really understand the story! ⭐";
    if (percentage >= 60) return "Great job! You're getting better at reading! 👏";
    return "Good try! Keep practicing and you'll improve! 💪";
  };

  if (gamePhase === 'start') {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 via-teal-50 to-green-50 flex items-center justify-center p-4">
        <div className="bg-white rounded-3xl shadow-lg p-8 max-w-md w-full text-center border border-blue-100">
          <div className="mb-6">
            <BookOpen className="h-16 w-16 text-teal-600 mx-auto mb-4" />
            <h1 className="text-3xl font-bold text-blue-800 mb-2">Reading Adventure</h1>
            <p className="text-blue-600 text-lg">Test your reading skills with fun stories!</p>
          </div>
          <button
            onClick={startGame}
            className="bg-gradient-to-r from-teal-500 to-blue-500 hover:from-teal-600 hover:to-blue-600 text-white font-semibold py-4 px-8 rounded-2xl transition-all duration-300 shadow-lg hover:shadow-xl transform hover:scale-105 text-xl"
          >
            Start Reading! 📖
          </button>
        </div>
      </div>
    );
  }

  if (gamePhase === 'story' && currentStory) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 via-teal-50 to-green-50 flex items-center justify-center p-4">
        <div className="bg-white rounded-3xl shadow-lg p-8 max-w-3xl w-full border border-blue-100">
          <div className="text-center mb-6">
            <h2 className="text-2xl font-bold text-blue-800 mb-4">{currentStory.title}</h2>
            <div className="h-1 bg-gradient-to-r from-teal-400 to-blue-400 rounded-full w-20 mx-auto"></div>
          </div>
          
          <div className="bg-blue-50 rounded-2xl p-6 mb-8 border border-blue-200">
            <p className="text-gray-800 text-lg leading-relaxed font-medium">
              {currentStory.content}
            </p>
          </div>

          <div className="text-center">
            <button
              onClick={startQuestions}
              className="bg-gradient-to-r from-teal-500 to-blue-500 hover:from-teal-600 hover:to-blue-600 text-white font-semibold py-3 px-6 rounded-2xl transition-all duration-300 shadow-lg hover:shadow-xl transform hover:scale-105 inline-flex items-center gap-2 text-lg"
            >
              Ready for Questions! <ChevronRight className="h-5 w-5" />
            </button>
          </div>
        </div>
      </div>
    );
  }

  if (gamePhase === 'questions' && currentStory) {
    const currentQuestion = currentStory.questions[currentQuestionIndex];
    const isCorrect = selectedAnswer === currentQuestion.correctAnswer;

    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 via-teal-50 to-green-50 flex items-center justify-center p-4">
        <div className="bg-white rounded-3xl shadow-lg p-8 max-w-2xl w-full border border-blue-100">
          {/* Progress Bar */}
          <div className="mb-6">
            <div className="flex justify-between items-center mb-2">
              <span className="text-sm font-medium text-blue-600">Progress</span>
              <span className="text-sm font-medium text-blue-600">
                Question {currentQuestionIndex + 1} of {currentStory.questions.length}
              </span>
            </div>
            <div className="w-full bg-blue-100 rounded-full h-2">
              <div
                className="bg-gradient-to-r from-teal-500 to-blue-500 h-2 rounded-full transition-all duration-300"
                style={{ width: `${((currentQuestionIndex + 1) / currentStory.questions.length) * 100}%` }}
              ></div>
            </div>
          </div>

          <h3 className="text-xl font-bold text-blue-800 mb-6 text-center">
            {currentQuestion.question}
          </h3>

          <div className="space-y-4 mb-8">
            {currentQuestion.options.map((option, index) => {
              let buttonClass = "w-full text-left p-4 rounded-2xl border-2 transition-all duration-300 font-medium text-lg ";
              
              if (!showFeedback) {
                if (selectedAnswer === index) {
                  buttonClass += "bg-blue-100 border-blue-400 shadow-md transform scale-105";
                } else {
                  buttonClass += "bg-gray-50 border-gray-200 hover:bg-blue-50 hover:border-blue-300 hover:shadow-md";
                }
              } else {
                if (index === currentQuestion.correctAnswer) {
                  buttonClass += "bg-green-100 border-green-400 text-green-800";
                } else if (selectedAnswer === index && selectedAnswer !== currentQuestion.correctAnswer) {
                  buttonClass += "bg-red-100 border-red-400 text-red-800";
                } else {
                  buttonClass += "bg-gray-100 border-gray-300 text-gray-600";
                }
              }

              return (
                <button
                  key={index}
                  onClick={() => handleAnswerSelect(index)}
                  onKeyPress={(e) => handleKeyPress(e, index)}
                  disabled={showFeedback}
                  className={buttonClass}
                >
                  <div className="flex items-center justify-between">
                    <span>{option}</span>
                    {showFeedback && index === currentQuestion.correctAnswer && (
                      <CheckCircle className="h-6 w-6 text-green-600" />
                    )}
                    {showFeedback && selectedAnswer === index && selectedAnswer !== currentQuestion.correctAnswer && (
                      <XCircle className="h-6 w-6 text-red-600" />
                    )}
                  </div>
                </button>
              );
            })}
          </div>

          {showFeedback && (
            <div className={`p-4 rounded-2xl mb-6 border-2 ${isCorrect ? 'bg-green-50 border-green-200' : 'bg-orange-50 border-orange-200'}`}>
              <div className="flex items-center gap-2 mb-2">
                {isCorrect ? (
                  <CheckCircle className="h-6 w-6 text-green-600" />
                ) : (
                  <XCircle className="h-6 w-6 text-orange-600" />
                )}
                <span className={`font-bold text-lg ${isCorrect ? 'text-green-800' : 'text-orange-800'}`}>
                  {isCorrect ? 'Correct! Great job! 🎉' : 'Not quite right, but good try! 💪'}
                </span>
              </div>
              {currentQuestion.explanation && (
                <p className={`${isCorrect ? 'text-green-700' : 'text-orange-700'} font-medium`}>
                  {currentQuestion.explanation}
                </p>
              )}
            </div>
          )}

          <div className="text-center">
            {!showFeedback ? (
              <button
                onClick={submitAnswer}
                disabled={selectedAnswer === null}
                className="bg-gradient-to-r from-teal-500 to-blue-500 hover:from-teal-600 hover:to-blue-600 disabled:from-gray-400 disabled:to-gray-500 disabled:cursor-not-allowed text-white font-semibold py-3 px-8 rounded-2xl transition-all duration-300 shadow-lg hover:shadow-xl transform hover:scale-105 text-lg"
              >
                Submit Answer
              </button>
            ) : (
              <button
                onClick={nextQuestion}
                className="bg-gradient-to-r from-teal-500 to-blue-500 hover:from-teal-600 hover:to-blue-600 text-white font-semibold py-3 px-8 rounded-2xl transition-all duration-300 shadow-lg hover:shadow-xl transform hover:scale-105 inline-flex items-center gap-2 text-lg"
              >
                {currentQuestionIndex < currentStory.questions.length - 1 ? (
                  <>Next Question <ChevronRight className="h-5 w-5" /></>
                ) : (
                  <>See Results <Star className="h-5 w-5" /></>
                )}
              </button>
            )}
          </div>
        </div>
      </div>
    );
  }

  if (gamePhase === 'complete' && currentStory) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 via-teal-50 to-green-50 flex items-center justify-center p-4">
        <div className="bg-white rounded-3xl shadow-lg p-8 max-w-lg w-full text-center border border-blue-100">
          <div className="mb-6">
            <Star className="h-16 w-16 text-yellow-500 mx-auto mb-4" />
            <h2 className="text-3xl font-bold text-blue-800 mb-2">Great Reading!</h2>
            <p className="text-gray-600 text-lg mb-4">You completed "{currentStory.title}"</p>
          </div>

          <div className="bg-gradient-to-r from-teal-50 to-blue-50 rounded-2xl p-6 mb-6 border border-blue-200">
            <div className="text-4xl font-bold text-blue-800 mb-2">
              {score} out of {currentStory.questions.length}
            </div>
            <div className="text-blue-600 font-medium text-lg mb-3">
              {Math.round((score / currentStory.questions.length) * 100)}% Correct
            </div>
            <p className="text-gray-700 font-medium">
              {getEncouragementMessage()}
            </p>
          </div>

          <div className="space-y-3">
            <button
              onClick={startGame}
              className="w-full bg-gradient-to-r from-teal-500 to-blue-500 hover:from-teal-600 hover:to-blue-600 text-white font-semibold py-3 px-6 rounded-2xl transition-all duration-300 shadow-lg hover:shadow-xl transform hover:scale-105 text-lg"
            >
              Try Another Story 📚
            </button>
            <button
              onClick={resetGame}
              className="w-full bg-gray-100 hover:bg-gray-200 text-gray-700 font-semibold py-3 px-6 rounded-2xl transition-all duration-300 shadow-md hover:shadow-lg inline-flex items-center justify-center gap-2 text-lg"
            >
              <RotateCcw className="h-5 w-5" />
              Back to Home
            </button>
          </div>
        </div>
      </div>
    );
  }

  return null;
}

export default App;